var Hashcontent = document.getElementById('Hashcontent').innerHTML; // html 안에 'content'라는 아이디를 content 라는 변수로 정의한다.
var splitedArray = Hashcontent.split(' '); // 공백을 기준으로 문자열을 자른다.
var linkedContent = '';
for(var word in splitedArray)
{
  word = splitedArray[word];
   if(word.indexOf('#') == 0) // # 문자를 찾는다.
   {
      word = '<a href=\링크>'+word+'</a>'; 
   }
   linkedContent += word+' ';
}
document.getElementById('Hashcontent').innerHTML = linkedContent;

  function printObj(obj) {
  var ret = "";

  if($.type(obj) == "string") {
    ret = obj;
  }

  else {
    for(var property in obj) {

      if(property == "title" || property == "hash tag" || property == "date") {
      ret += property + " : ";
      }

    if(property != "memo"){
      ret += printObj(obj[property]) + "\n";
      } 

    }
  }
  
  return ret;
}


















